# -*- coding: utf-8 -*-
# encoding: utf-8  

"""
Created on Tue Oct 30 16:50:24 2018

@author: liuhuwei
@describe: 抓取大众点评评论信息
"""

import csv
import requests
from pyquery import PyQuery as pq
from fake_useragent import UserAgent
import time, random

ua = UserAgent()

#设置cookies
cookie = "_lxsdk_cuid=162760423dfc8-0801f141cb0731-3b60490d-e1000-162760423dfc8; _lxsdk=162760423dfc8-0801f141cb0731-3b60490d-e1000-162760423dfc8; _hc.v=af7219c3-2b99-8bb8-f9b2-7b1d9be7f29e.1522398406; s_ViewType=10; ua=%E4%BB%A4%E7%8B%90%E5%86%B2; ctu=029e953356caf94d20233d299a70d285a03cb64585c371690b17d3e59c4c075c; cye=guangzhou; Hm_lvt_e6f449471d3527d58c46e24efb4c343e=1531964746; cy=4; dper=8c6ae023e893759ea57ce154028f1800be56b69450806b893b9cf5c6b6c3e3ba3c986c9a603bcbf9a7fb18dcd2038cf704b3e3baba3532bc7dffec965fe5e6c3b2479ca21c6577a1f5636088acbba8936df6ac994e02a923a907907a938559f9; ll=7fd06e815b796be3df069dec7836c3df; _lx_utm=utm_source%3DBaidu%26utm_medium%3Dorganic; _lxsdk_s=1661889a264-50e-66f-22a%7C%7C276"

#修改请求头
headers = {
        'User-Agent':ua.random,
        'Cookie':cookie,
        'Connection':'keep-alive',
        'Host':'www.dianping.com',
        'Referer': 'http://www.dianping.com/shop/521698/review_all/p6'
}

ips = open('ip.txt','r').read().split('\n')

def get_random_ip():
    ip = random.choice(ips)
    pxs = {ip.split(':')[0]:ip}
    return pxs

def spiderDazhong(ID):
    try:
        time.sleep(random.random()*6 + 2)
        html = requests.get("http://www.dianping.com/shop/%s/review_all"%(ID), timeout = 5, headers=headers, 
                       proxies=get_random_ip())
        doc = pq(html.text)
        if doc:
            # 存入csv文件
            out = open('./Stu_csv.csv', 'a', newline='',encoding="utf-8")
            # 设定写入模式
            csv_write = csv.writer(out, dialect='excel')
            shopName = doc("div.review-list-header > h1 > a").text()
            shopurl = "http://www.dianping.com"+doc("div.review-list-header > h1 > a").attr("href")
            csv_write.writerow(["店铺名称","店铺网址"])
            csv_write.writerow([shopName,shopurl])
            csv_write.writerow(["用户名", "用户ID链接", "评定星级", "评论描述", "评论详情", "评论时间", "评论商铺", "评论图片"])
            # 解析评论
            pinglunLi = doc("div.reviews-items > ul > li").items()
            for data in pinglunLi:
                userName = data("div.main-review > div.dper-info > a").text()
                userID = "http://www.dianping.com"+data("div.main-review > div.dper-info > a").attr("href")
                startShop = str(data("div.review-rank > span").attr("class")).split(" ")[1].replace("sml-str","")
                describeShop = data("div.review-rank > span.score").text()
                pinglunShop = data("div > div.review-words").text().replace("收起评论","").replace(" ","").replace("\n","")
                timeShop = data("div.main-review > div.misc-info.clearfix > span.time").text()
                Shop = data("div.main-review > div.misc-info.clearfix > span.shop").text()
                imgShop = data("div > div.review-pictures > ul > li> a").items()
                imgList = []
                for img in imgShop:
                    imgList.append("http://www.dianping.com"+img.attr("href"))

                # 写入具体内容
                csv_write.writerow([userName,userID,startShop,describeShop,pinglunShop,timeShop,Shop,imgList])
                print("successful insert csv!")

    except Exception as e:
        print("error",str(e))


if __name__ == '__main__':
    # 代表各大商铺ID，可通过商铺列表页回去
    listShop = ["2972056", "91018291","69952338"]
    for shop in listShop:
        spiderDazhong(shop)