# -*- coding: utf-8 -*-
"""
Created on Sun Oct 28 17:58:26 2018

@author:liuhuwei

"""

import requests
import time, random
from fake_useragent import UserAgent
from lxml import etree
import xlwt
import re
import craw_ip

ua = UserAgent()

#设置cookies
cookie = "_lxsdk_cuid=162760423dfc8-0801f141cb0731-3b60490d-e1000-162760423dfc8; _lxsdk=162760423dfc8-0801f141cb0731-3b60490d-e1000-162760423dfc8; _hc.v=af7219c3-2b99-8bb8-f9b2-7b1d9be7f29e.1522398406; s_ViewType=10; ua=%E4%BB%A4%E7%8B%90%E5%86%B2; ctu=029e953356caf94d20233d299a70d285a03cb64585c371690b17d3e59c4c075c; cye=guangzhou; Hm_lvt_e6f449471d3527d58c46e24efb4c343e=1531964746; cy=4; dper=8c6ae023e893759ea57ce154028f1800be56b69450806b893b9cf5c6b6c3e3ba3c986c9a603bcbf9a7fb18dcd2038cf704b3e3baba3532bc7dffec965fe5e6c3b2479ca21c6577a1f5636088acbba8936df6ac994e02a923a907907a938559f9; ll=7fd06e815b796be3df069dec7836c3df; _lx_utm=utm_source%3DBaidu%26utm_medium%3Dorganic; _lxsdk_s=1661889a264-50e-66f-22a%7C%7C276"

#修改请求头
headers = {
        'User-Agent':ua.random,
        'Cookie':cookie,
        'Connection':'keep-alive',
        'Host':'www.dianping.com',
        'Referer': 'http://www.dianping.com/shop/521698/review_all/p6'
}
#url = 'https://m.dianping.com/shoplist/2/search?from=m_search&keyword=%E5%BF%AB%E9%80%92&from_suggest=suggest_0'
url = "https://www.dianping.com/search/keyword/2/0_%E5%BF%AB%E9%80%92"
#从ip代理池中随机获取ip
ips = open('ip.txt','r').read().split('\n')

style1 = xlwt.XFStyle()

font1 = xlwt.Font()
font1.name = '微软雅黑'
font1.bold = True
font1.colour_index = 0
font1.height = 220
style1.font = font1

borders = xlwt.Borders()
borders.left = xlwt.Borders.THIN
borders.right = xlwt.Borders.THIN
borders.top = xlwt.Borders.THIN
borders.bottom = xlwt.Borders.THIN
style1.borders = borders

style2 = xlwt.XFStyle()

font2 = xlwt.Font()
font2.name = '宋体'
font2.colour_index = 0
font2.height = 220
style2.font = font2
style2.borders = borders

al = xlwt.Alignment()
al.horz = 0x02
al.vert = 0x01
style1.alignment = al

def get_random_ip():
    ip = random.choice(ips)
    pxs = {ip.split(':')[0]:ip}
    return pxs

#获取html页面
urlslist = []
shopidlist = []
shopidlist2 = []
def getHTMLText(url,code="utf-8"):
    try:
        j = 0
        for m in range(1,2):
            time.sleep(random.random()*6 + 2)
            r=requests.get(url, timeout = 5, headers=headers, 
                       proxies=get_random_ip()
                       )
            r.raise_for_status()
            r.encoding = code
            #return r.text
            html = etree.HTML(r.text)
            #print(r.text)
            for i in range(1,16):
                shopinfor = []
                shopinfor2 = []
                title = html.xpath('//*[@id="shop-all-list"]/ul/li[' + str(i) + ']/div[2]/div[1]/a/@href' )
                shopname = html.xpath('//*[@id="shop-all-list"]/ul/li[' + str(i) + ']/div[2]/div[1]/a/h4/text()')
                shopid = re.sub("\D", "", str(title))
                shopidlist.append(shopid)
                print(shopname)
                print(title)
                if shopidlist.count(shopid) == 1:
                    if len(title) == 1:
                        j += 1
                        shopinfor2.append(shopid)
                        shopinfor2.append(shopname)
                        shopidlist2.append(shopinfor2)
                        shopinfor.append(j)
                        shopinfor.append(shopname)
                        shopinfor.append(title)
                        shopinfor.append(int(shopid))
                        urlslist.append(shopinfor)
            print("——————————————————")
            print("第%d页OK....." % m)
            print("——————————————————")
            #time.sleep(1)
            m += 1
            url = "https://www.dianping.com/search/keyword/2/0_%E5%BF%AB%E9%80%92/p" + str(m)
    except:
        print("产生异常")
        return "产生异常"
print(urlslist)
getHTMLText(url,code="utf-8")
book = xlwt.Workbook()
sheet = book.add_sheet('商家ID')

sheet.write(0, 0, "序号", style1)
sheet.write(0, 1, "商家名称", style1)
sheet.write(0, 2, "链接", style1)
sheet.write(0, 3, "商家ID", style1)

title_col = sheet.col(1)
title_col.width = 256*30
url_col = sheet.col(2)
url_col.width = 256*50
id_col = sheet.col(3)
id_col.width = 256*15

row = 1
for stu in urlslist:
    col = 0
    for s in stu:
        sheet.write(row,col,s, style2)
        col += 1
    row += 1
book.save('urls.xls')